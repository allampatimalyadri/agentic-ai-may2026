"""
=============================================================
  PYTHON CODING CHALLENGE
  Topic   : LangGraph · Advanced RAG · Multimodal RAG
  Level   : Intermediate → Advanced
  Tasks   : 10  (project-style, grouped by topic)
=============================================================

SETUP — install dependencies before you begin
----------------------------------------------
  pip install langgraph langchain langchain-openai
              langchain-community langchain-core
              psycopg2-binary python-dotenv numpy

ENVIRONMENT VARIABLES — create a .env file:
  OPENAI_API_KEY       = "sk-..."
  PG_CONNECTION_STRING = "postgresql+psycopg2://user:pass@localhost:5432/vectordb"

TOPIC SECTIONS
--------------
  Section A — LangGraph               (Tasks  1 – 4)
  Section B — Advanced RAG            (Tasks  5 – 7)
  Section C — Multimodal RAG          (Tasks  8 – 10)

RULES
-----
  - Implement every function stub below.
  - Keep function signatures exactly as given.
  - Handle API errors gracefully with try/except.
  - For multimodal tasks a sample image is auto-created
    in the setup block — no external files needed.
=============================================================
"""

import os
import base64
import numpy as np
from dotenv import load_dotenv

load_dotenv()


# ─────────────────────────────────────────────────────────────
# SETUP — auto-creates a tiny sample PNG for multimodal tasks
# (already implemented — do NOT modify)
# ─────────────────────────────────────────────────────────────

def create_sample_image(path: str) -> str:
    """
    Writes a minimal valid 1x1 red pixel PNG to `path`.
    Returns the path. Used by Section C tasks.
    """
    # Minimal 1×1 red-pixel PNG (67 bytes, base64-encoded)
    PNG_B64 = (
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8"
        "z8BQDwADhQGAWjR9awAAAABJRU5ErkJggg=="
    )
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "wb") as f:
        f.write(base64.b64decode(PNG_B64))
    return path


# ─────────────────────────────────────────────────────────────
# SECTION A — LangGraph  (Tasks 1 – 4)
# ─────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────
# TASK 1 — Basic StateGraph: Summarise → Critique Pipeline
# ─────────────────────────────────────────────────────────────
"""
TASK 1: Basic StateGraph
--------------------------
Build a two-node LangGraph pipeline:
  Node 1  "summarise"  — summarises the input text in 2 sentences.
  Node 2  "critique"   — critiques the summary in 1 sentence.

Define the graph state as a TypedDict with:
  {"input": str, "summary": str, "critique": str}

Wire up:  START → summarise → critique → END

Return the final state dict after invoking with input_text.

HINT:
  from typing import TypedDict
  from langgraph.graph import StateGraph, START, END

  class State(TypedDict):
      input   : str
      summary : str
      critique: str

  def summarise_node(state: State) -> dict:
      # call LLM, return {"summary": "..."}

  builder = StateGraph(State)
  builder.add_node("summarise", summarise_node)
  builder.add_edge(START, "summarise")
  ...
  graph = builder.compile()
  result = graph.invoke({"input": input_text, "summary": "", "critique": ""})
"""

def basic_state_graph(input_text: str) -> dict:
    """Runs a summarise → critique LangGraph. Returns final state dict."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# TASK 2 — Conditional Routing in LangGraph
# ─────────────────────────────────────────────────────────────
"""
TASK 2: Conditional Routing
-----------------------------
Build a graph that:
  1. Calls an LLM to answer a yes/no question.
  2. Uses a conditional edge to route:
       - If the answer contains "yes" → node "affirm"
         (appends "Great! The answer is YES." to the state)
       - Otherwise              → node "deny"
         (appends "The answer is NO." to the state)
  3. Both nodes lead to END.

State: {"question": str, "raw_answer": str, "final_response": str}

Return the final state dict.

HINT:
  builder.add_conditional_edges(
      "llm_node",
      routing_function,          # takes state, returns node name string
      {"affirm": "affirm", "deny": "deny"}
  )

  def routing_function(state: State) -> str:
      if "yes" in state["raw_answer"].lower():
          return "affirm"
      return "deny"
"""

def conditional_routing_graph(question: str) -> dict:
    """Routes to affirm/deny based on LLM answer. Returns final state."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# TASK 3 — Agentic Loop: Tool-Calling ReAct Graph
# ─────────────────────────────────────────────────────────────
"""
TASK 3: ReAct Agent Loop with LangGraph
-----------------------------------------
Build a cyclic LangGraph that implements a ReAct agent manually:

  Nodes:
    "agent"  — binds tools to the LLM and calls it.
               If the LLM responds with tool_calls → go to "tools".
               If not (final answer)               → go to END.
    "tools"  — executes the tool calls and appends results to messages.
               Always loops back to "agent".

  State: {"messages": Annotated[list[BaseMessage], add_messages]}

  Tools to provide:
    - multiply(a: int, b: int) → int    (returns a * b)
    - add(a: int, b: int) → int         (returns a + b)

Test query:  "What is (7 * 6) + 15?"
Return the final assistant message content as a string.

HINT:
  from langgraph.graph.message import add_messages
  from langchain_core.messages import BaseMessage, ToolMessage
  from typing import Annotated

  # Bind tools to LLM:
  llm_with_tools = llm.bind_tools(tools)

  # Check for tool calls:
  if state["messages"][-1].tool_calls:
      return "tools"
  return END

  # In tools node, iterate tool_calls and create ToolMessage results.
"""

def react_agent_graph(query: str) -> str:
    """Runs a cyclic ReAct LangGraph with math tools. Returns final answer."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# TASK 4 — LangGraph with MemorySaver (Checkpointing)
# ─────────────────────────────────────────────────────────────
"""
TASK 4: LangGraph with Checkpointing
---------------------------------------
Add MemorySaver to the ReAct graph from Task 3 (or build a
simpler chat graph) so conversations persist across invocations
using a thread_id.

Requirements:
  - Use MemorySaver as the checkpointer.
  - Simulate a 2-turn chat on the SAME thread_id:
      Turn 1: "My favourite number is 42. Remember it."
      Turn 2: "What is my favourite number multiplied by 2?"
  - The second turn should recall 42 from memory → answer 84.
  - Return both answers as a list: [answer_turn1, answer_turn2]

HINT:
  from langgraph.checkpoint.memory import MemorySaver
  memory   = MemorySaver()
  graph    = builder.compile(checkpointer=memory)
  config   = {"configurable": {"thread_id": "session-1"}}

  # Invoke with the same config both times to share state.
  result1  = graph.invoke({"messages": [HumanMessage(turn1)]}, config)
  result2  = graph.invoke({"messages": [HumanMessage(turn2)]}, config)
"""

def graph_with_checkpointing() -> list:
    """Runs a 2-turn chat graph with memory. Returns [answer1, answer2]."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# SECTION B — Advanced RAG  (Tasks 5 – 7)
# ─────────────────────────────────────────────────────────────

RAG_DOCS = [
    "LangGraph is a library for building stateful, multi-actor LLM applications using graph-based workflows.",
    "Corrective RAG (CRAG) grades retrieved documents and falls back to web search if they are irrelevant.",
    "Multi-query RAG generates several rephrased versions of a user query and merges the retrieved results.",
    "Self-RAG uses reflection tokens to decide when to retrieve, and grades its own generated output.",
    "Query rewriting improves RAG by transforming an ambiguous question into a clearer retrieval query.",
    "pgvector supports three distance metrics: L2 distance, inner product, and cosine distance.",
    "LangSmith can log every retrieval step, making it easy to debug RAG pipeline quality.",
    "Multimodal RAG extends retrieval to images by embedding image descriptions alongside text chunks.",
]


# ─────────────────────────────────────────────────────────────
# TASK 5 — Query Rewriting RAG
# ─────────────────────────────────────────────────────────────
"""
TASK 5: Query Rewriting RAG
-----------------------------
Before retrieving, rewrite the user's ambiguous query into a
clearer, more specific retrieval query.  Then run standard RAG.

Pipeline:
  original query
       ↓
  [rewrite_node]  — LLM rewrites into a better search query
       ↓
  [retrieve_node] — retrieves top-3 docs with the rewritten query
       ↓
  [answer_node]   — answers using retrieved context
       ↓
  returns {"original": str, "rewritten": str, "answer": str}

Test query:  "How does the graph thing work with memory?"

HINT:
  rewrite_prompt = ChatPromptTemplate.from_template(
      "Rewrite this query to be more specific for a technical "
      "knowledge base search. Return ONLY the rewritten query.\n"
      "Original: {query}"
  )
  # Then use the rewritten query for retrieval, not the original.
"""

def query_rewriting_rag(query: str, documents: list) -> dict:
    """Rewrites query then runs RAG. Returns original, rewritten, and answer."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# TASK 6 — Multi-Query RAG
# ─────────────────────────────────────────────────────────────
"""
TASK 6: Multi-Query RAG
-------------------------
Generate 3 different rephrasings of the user query, retrieve
documents for each, deduplicate, then generate a final answer.

Steps:
  1. Use an LLM to generate 3 query variants (return as list).
  2. Retrieve top-2 docs for EACH variant.
  3. Deduplicate by page_content (use a set).
  4. Answer with the merged unique context.
  5. Return:
     {
       "original_query"   : str,
       "generated_queries": list[str],
       "unique_doc_count" : int,
       "answer"           : str,
     }

Test query:  "What techniques improve RAG accuracy?"

HINT:
  multi_query_prompt = ChatPromptTemplate.from_template(
      "Generate 3 different search queries for this question. "
      "Return them as a numbered list (1. ... 2. ... 3. ...).\n"
      "Question: {question}"
  )
  # Parse the numbered list from the LLM output.
  # Use a set of page_content strings to deduplicate.
"""

def multi_query_rag(query: str, documents: list) -> dict:
    """Multi-query RAG with deduplication. Returns queries, doc count, answer."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# TASK 7 — Self-RAG with Document Grading
# ─────────────────────────────────────────────────────────────
"""
TASK 7: Self-RAG with Document Grading
-----------------------------------------
After retrieval, grade each document as relevant or irrelevant
to the query.  Only use relevant docs to generate the answer.
If ZERO relevant docs are found, return "I don't know."

Steps:
  1. Retrieve top-4 docs for the query.
  2. For each doc, ask the LLM: "Is this document relevant to
     answering: '{query}'? Answer YES or NO only."
  3. Keep only docs where the answer is YES.
  4. If no relevant docs → return "I don't know."
  5. Otherwise answer from the relevant docs.
  6. Return:
     {
       "query"           : str,
       "retrieved_count" : int,
       "relevant_count"  : int,
       "answer"          : str,
     }

Test with:
  query_relevant  = "What distance metrics does pgvector support?"
  query_irrelevant = "What is the capital of France?"

HINT:
  grade_prompt = ChatPromptTemplate.from_template(
      "Is the following document relevant to answering: '{query}'?\n"
      "Document: {document}\n"
      "Answer YES or NO only."
  )
"""

def self_rag_with_grading(query: str, documents: list) -> dict:
    """Grades retrieved docs for relevance before answering."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# SECTION C — Multimodal RAG  (Tasks 8 – 10)
# ─────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────
# TASK 8 — Describe an Image with GPT-4o Vision
# ─────────────────────────────────────────────────────────────
"""
TASK 8: Image Description with GPT-4o Vision
----------------------------------------------
Write a function that:
  1. Reads an image file from disk.
  2. Encodes it as a base64 string.
  3. Sends it to GPT-4o with a text prompt via a HumanMessage
     that contains both text and image_url content blocks.
  4. Returns a structured dict:
     {
       "image_path"  : str,
       "description" : str,
       "tags"        : list[str]   # extracted from the description
     }

The tags should be extracted by a second LLM call that turns
the description into a comma-separated keyword list.

HINT:
  from langchain_core.messages import HumanMessage

  with open(image_path, "rb") as f:
      b64 = base64.b64encode(f.read()).decode("utf-8")

  message = HumanMessage(content=[
      {"type": "text", "text": "Describe this image in detail."},
      {"type": "image_url",
       "image_url": {"url": f"data:image/png;base64,{b64}"}}
  ])
  llm = ChatOpenAI(model="gpt-4o", max_tokens=300)
  response = llm.invoke([message])
"""

def describe_image(image_path: str) -> dict:
    """Describes an image using GPT-4o. Returns description and tags."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# TASK 9 — Build a Multimodal Document Index
# ─────────────────────────────────────────────────────────────
"""
TASK 9: Multimodal Document Index
------------------------------------
Build a vector store that indexes BOTH text documents and
image descriptions side by side.

Given:
  text_docs   = list of strings
  image_paths = list of image file paths

Steps:
  1. Embed all text_docs as Documents with metadata {"type": "text"}.
  2. For each image: call describe_image() to get the description,
     then embed it as a Document with metadata:
       {"type": "image", "image_path": path, "tags": tags_list}
  3. Store all documents in a PGVector collection called
     "multimodal_index".
  4. Return a summary dict:
     {
       "text_docs_indexed" : int,
       "image_docs_indexed": int,
       "total_indexed"     : int,
       "collection"        : str,
     }

HINT:
  from langchain_core.documents import Document
  from langchain_community.vectorstores import PGVector

  docs = []
  for text in text_docs:
      docs.append(Document(page_content=text, metadata={"type": "text"}))
  for path in image_paths:
      info = describe_image(path)
      docs.append(Document(
          page_content=info["description"],
          metadata={"type": "image", "image_path": path, "tags": info["tags"]}
      ))
"""

def build_multimodal_index(text_docs: list, image_paths: list) -> dict:
    """Indexes text + image descriptions into a PGVector store."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# ─────────────────────────────────────────────────────────────
# TASK 10 — Multimodal RAG Query with Source Attribution
# ─────────────────────────────────────────────────────────────
"""
TASK 10: Multimodal RAG Query
-------------------------------
Query the multimodal index (built in Task 9) and return an
answer that identifies whether each source was TEXT or IMAGE.

Steps:
  1. Connect to the existing "multimodal_index" PGVector store.
  2. Retrieve top-3 most relevant documents for the query.
  3. Build context from the retrieved docs.
  4. Generate an answer using ChatOpenAI.
  5. Return:
     {
       "query"  : str,
       "answer" : str,
       "sources": [
           {"type": "text"|"image", "content": str, "score": float},
           ...
       ]
     }

Test queries:
  "What does the image show?"
  "What techniques extend RAG to images?"

HINT:
  store = PGVector(
      collection_name="multimodal_index",
      connection_string=os.environ["PG_CONNECTION_STRING"],
      embedding_function=embeddings,
  )
  results = store.similarity_search_with_score(query, k=3)
  for doc, score in results:
      source_type = doc.metadata.get("type", "text")
"""

def multimodal_rag_query(query: str) -> dict:
    """Queries the multimodal index and returns answer with source types."""
    # ── YOUR CODE BELOW ──────────────────────────────────────

    pass

    # ── END OF YOUR CODE ─────────────────────────────────────


# =============================================================
#  MAIN — test harness for all 10 tasks
# =============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("LangGraph · Advanced RAG · Multimodal RAG")
    print("10-Task Coding Challenge")
    print("=" * 60)

    # Setup: sample image for Section C
    SAMPLE_IMAGE = create_sample_image("challenge_assets/sample.png")

    # ── Section A: LangGraph ─────────────────────────────────
    print("\n── SECTION A: LangGraph ───────────────────────────────\n")

    print("[Task 1] Basic StateGraph")
    r1 = basic_state_graph("LangGraph enables complex multi-step LLM workflows.")
    print("  Summary  :", r1.get("summary", "")[:80])
    print("  Critique :", r1.get("critique", "")[:80])

    print("\n[Task 2] Conditional Routing")
    r2 = conditional_routing_graph("Is Python a programming language?")
    print("  Raw answer    :", r2.get("raw_answer", "")[:60])
    print("  Final response:", r2.get("final_response", "")[:80])

    print("\n[Task 3] ReAct Agent Loop")
    r3 = react_agent_graph("What is (7 * 6) + 15?")
    print("  Answer:", r3)

    print("\n[Task 4] Graph with Checkpointing")
    r4 = graph_with_checkpointing()
    print("  Turn 1:", str(r4[0])[:80] if r4 else "")
    print("  Turn 2:", str(r4[1])[:80] if len(r4) > 1 else "")

    # ── Section B: Advanced RAG ──────────────────────────────
    print("\n── SECTION B: Advanced RAG ────────────────────────────\n")

    print("[Task 5] Query Rewriting RAG")
    r5 = query_rewriting_rag("How does the graph thing work with memory?", RAG_DOCS)
    print("  Original :", r5.get("original", "")[:60])
    print("  Rewritten:", r5.get("rewritten", "")[:60])
    print("  Answer   :", r5.get("answer", "")[:100])

    print("\n[Task 6] Multi-Query RAG")
    r6 = multi_query_rag("What techniques improve RAG accuracy?", RAG_DOCS)
    print("  Variants generated:", r6.get("generated_queries"))
    print("  Unique docs used  :", r6.get("unique_doc_count"))
    print("  Answer            :", r6.get("answer", "")[:100])

    print("\n[Task 7] Self-RAG with Grading")
    r7a = self_rag_with_grading("What distance metrics does pgvector support?", RAG_DOCS)
    print("  [Relevant query]")
    print(f"  Retrieved: {r7a.get('retrieved_count')}  Relevant: {r7a.get('relevant_count')}")
    print(f"  Answer: {r7a.get('answer', '')[:100]}")

    r7b = self_rag_with_grading("What is the capital of France?", RAG_DOCS)
    print("  [Irrelevant query]")
    print(f"  Retrieved: {r7b.get('retrieved_count')}  Relevant: {r7b.get('relevant_count')}")
    print(f"  Answer: {r7b.get('answer', '')[:60]}")

    # ── Section C: Multimodal RAG ────────────────────────────
    print("\n── SECTION C: Multimodal RAG ──────────────────────────\n")

    print("[Task 8] Describe Image with GPT-4o")
    r8 = describe_image(SAMPLE_IMAGE)
    print("  Description:", r8.get("description", "")[:100])
    print("  Tags       :", r8.get("tags"))

    print("\n[Task 9] Build Multimodal Index")
    r9 = build_multimodal_index(RAG_DOCS, [SAMPLE_IMAGE])
    print(f"  Text docs  : {r9.get('text_docs_indexed')}")
    print(f"  Image docs : {r9.get('image_docs_indexed')}")
    print(f"  Total      : {r9.get('total_indexed')}")

    print("\n[Task 10] Multimodal RAG Query")
    r10 = multimodal_rag_query("What techniques extend RAG to images?")
    print("  Answer  :", r10.get("answer", "")[:120])
    print("  Sources :")
    for s in r10.get("sources", []):
        print(f"    [{s.get('type','?').upper()}  score={s.get('score', 0):.4f}]"
              f" {s.get('content', '')[:60]}")

    print("\n" + "=" * 60)
    print("All 10 tasks complete!")
    print("=" * 60)
