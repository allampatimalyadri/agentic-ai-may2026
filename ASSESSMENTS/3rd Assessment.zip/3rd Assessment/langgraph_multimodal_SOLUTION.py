"""
=============================================================
  SOLUTION FILE
  Topic   : LangGraph · Advanced RAG · Multimodal RAG
  Tasks   : 10
=============================================================
  Run:  python langgraph_multimodal_SOLUTION.py
=============================================================
"""

import os
import re
import json
import base64
import numpy as np
from typing import TypedDict, Annotated
from dotenv import load_dotenv

load_dotenv()

# ── LangChain core ────────────────────────────────────────────
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.documents import Document
from langchain_core.messages import (
    BaseMessage, HumanMessage, AIMessage, ToolMessage
)

# ── LangChain OpenAI ──────────────────────────────────────────
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

# ── LangChain community ───────────────────────────────────────
from langchain_community.vectorstores import PGVector

# ── LangGraph ─────────────────────────────────────────────────
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

# ── LangChain tools ───────────────────────────────────────────
from langchain.tools import tool

# ─────────────────────────────────────────────────────────────
# Shared helpers
# ─────────────────────────────────────────────────────────────

def _llm(model: str = "gpt-4o-mini", temperature: float = 0) -> ChatOpenAI:
    return ChatOpenAI(model=model, temperature=temperature)

def _embeddings() -> OpenAIEmbeddings:
    return OpenAIEmbeddings(model="text-embedding-3-small")

def _pgvector_store(collection: str, docs: list = None,
                    pre_delete: bool = False) -> PGVector:
    emb = _embeddings()
    if docs:
        return PGVector.from_documents(
            documents=docs,
            embedding=emb,
            collection_name=collection,
            connection_string=os.environ["PG_CONNECTION_STRING"],
            pre_delete_collection=pre_delete,
        )
    return PGVector(
        collection_name=collection,
        connection_string=os.environ["PG_CONNECTION_STRING"],
        embedding_function=emb,
    )


# ─────────────────────────────────────────────────────────────
# SETUP
# ─────────────────────────────────────────────────────────────

def create_sample_image(path: str) -> str:
    PNG_B64 = (
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8"
        "z8BQDwADhQGAWjR9awAAAABJRU5ErkJggg=="
    )
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "wb") as f:
        f.write(base64.b64decode(PNG_B64))
    return path


RAG_DOCS = [
    "LangGraph is a library for building stateful, multi-actor LLM applications using graph-based workflows.",
    "Corrective RAG (CRAG) grades retrieved documents and falls back to web search if they are irrelevant.",
    "Multi-query RAG generates several rephrased versions of a user query and merges the retrieved results.",
    "Self-RAG uses reflection tokens to decide when to retrieve, and grades its own generated output.",
    "Query rewriting improves RAG by transforming an ambiguous question into a clearer retrieval query.",
    "pgvector supports three distance metrics: L2 distance, inner product, and cosine distance.",
    "LangSmith can log every retrieval step, making it easy to debug RAG pipeline quality.",
    "Multimodal RAG extends retrieval to images by embedding image descriptions alongside text chunks.",
]


# =============================================================
# SECTION A — LangGraph
# =============================================================

# ─────────────────────────────────────────────────────────────
# TASK 1 SOLUTION — Basic StateGraph
# ─────────────────────────────────────────────────────────────

def basic_state_graph(input_text: str) -> dict:
    """Runs a summarise → critique LangGraph. Returns final state dict."""

    # Define state schema
    class State(TypedDict):
        input   : str
        summary : str
        critique: str

    llm    = _llm()
    parser = StrOutputParser()

    # Node 1: summarise
    def summarise_node(state: State) -> dict:
        prompt = ChatPromptTemplate.from_template(
            "Summarise the following text in exactly 2 sentences:\n\n{text}"
        )
        chain   = prompt | llm | parser
        summary = chain.invoke({"text": state["input"]})
        return {"summary": summary}

    # Node 2: critique
    def critique_node(state: State) -> dict:
        prompt = ChatPromptTemplate.from_template(
            "In exactly 1 sentence, critique this summary:\n\n{summary}"
        )
        chain    = prompt | llm | parser
        critique = chain.invoke({"summary": state["summary"]})
        return {"critique": critique}

    # Build graph
    builder = StateGraph(State)
    builder.add_node("summarise", summarise_node)
    builder.add_node("critique",  critique_node)

    builder.add_edge(START,       "summarise")
    builder.add_edge("summarise", "critique")
    builder.add_edge("critique",  END)

    graph = builder.compile()

    return graph.invoke({"input": input_text, "summary": "", "critique": ""})


# ─────────────────────────────────────────────────────────────
# TASK 2 SOLUTION — Conditional Routing
# ─────────────────────────────────────────────────────────────

def conditional_routing_graph(question: str) -> dict:
    """Routes to affirm/deny based on LLM answer. Returns final state."""

    class State(TypedDict):
        question      : str
        raw_answer    : str
        final_response: str

    llm    = _llm()
    parser = StrOutputParser()

    # LLM node — answers yes/no
    def llm_node(state: State) -> dict:
        prompt = ChatPromptTemplate.from_template(
            "Answer this question with YES or NO only: {question}"
        )
        raw = (prompt | llm | parser).invoke({"question": state["question"]})
        return {"raw_answer": raw}

    # Routing function
    def route(state: State) -> str:
        return "affirm" if "yes" in state["raw_answer"].lower() else "deny"

    # Outcome nodes
    def affirm_node(state: State) -> dict:
        return {"final_response": "Great! The answer is YES."}

    def deny_node(state: State) -> dict:
        return {"final_response": "The answer is NO."}

    # Build graph
    builder = StateGraph(State)
    builder.add_node("llm_node", llm_node)
    builder.add_node("affirm",   affirm_node)
    builder.add_node("deny",     deny_node)

    builder.add_edge(START, "llm_node")
    builder.add_conditional_edges(
        "llm_node",
        route,
        {"affirm": "affirm", "deny": "deny"},
    )
    builder.add_edge("affirm", END)
    builder.add_edge("deny",   END)

    graph = builder.compile()

    return graph.invoke({
        "question": question, "raw_answer": "", "final_response": ""
    })


# ─────────────────────────────────────────────────────────────
# TASK 3 SOLUTION — ReAct Agent Loop
# ─────────────────────────────────────────────────────────────

def react_agent_graph(query: str) -> str:
    """Runs a cyclic ReAct LangGraph with math tools. Returns final answer."""

    # Define state with message list and add_messages reducer
    class State(TypedDict):
        messages: Annotated[list[BaseMessage], add_messages]

    # Define tools
    @tool
    def multiply(a: int, b: int) -> int:
        """Multiplies two integers."""
        return a * b

    @tool
    def add(a: int, b: int) -> int:
        """Adds two integers."""
        return a + b

    tools          = [multiply, add]
    tools_by_name  = {t.name: t for t in tools}
    llm_with_tools = _llm().bind_tools(tools)

    # Agent node — calls LLM with tools bound
    def agent_node(state: State) -> dict:
        response = llm_with_tools.invoke(state["messages"])
        return {"messages": [response]}

    # Tools node — executes all pending tool calls
    def tools_node(state: State) -> dict:
        last_message = state["messages"][-1]
        tool_messages = []

        for tool_call in last_message.tool_calls:
            fn     = tools_by_name[tool_call["name"]]
            result = fn.invoke(tool_call["args"])
            tool_messages.append(
                ToolMessage(
                    content=str(result),
                    tool_call_id=tool_call["id"],
                )
            )
        return {"messages": tool_messages}

    # Routing: if last message has tool calls → tools node, else END
    def should_continue(state: State) -> str:
        last = state["messages"][-1]
        if hasattr(last, "tool_calls") and last.tool_calls:
            return "tools"
        return END

    # Build graph
    builder = StateGraph(State)
    builder.add_node("agent", agent_node)
    builder.add_node("tools", tools_node)

    builder.add_edge(START,   "agent")
    builder.add_conditional_edges("agent", should_continue, {"tools": "tools", END: END})
    builder.add_edge("tools", "agent")   # loop back after tool execution

    graph = builder.compile()

    result = graph.invoke({"messages": [HumanMessage(content=query)]})

    # Return the content of the last AI message
    for msg in reversed(result["messages"]):
        if isinstance(msg, AIMessage) and msg.content:
            return msg.content

    return str(result["messages"][-1].content)


# ─────────────────────────────────────────────────────────────
# TASK 4 SOLUTION — LangGraph with Checkpointing
# ─────────────────────────────────────────────────────────────

def graph_with_checkpointing() -> list:
    """Runs a 2-turn chat graph with memory. Returns [answer1, answer2]."""

    class State(TypedDict):
        messages: Annotated[list[BaseMessage], add_messages]

    llm = _llm()

    def chat_node(state: State) -> dict:
        response = llm.invoke(state["messages"])
        return {"messages": [response]}

    builder = StateGraph(State)
    builder.add_node("chat", chat_node)
    builder.add_edge(START, "chat")
    builder.add_edge("chat", END)

    # Attach MemorySaver as checkpointer
    memory = MemorySaver()
    graph  = builder.compile(checkpointer=memory)

    config = {"configurable": {"thread_id": "task4-session"}}

    turns = [
        "My favourite number is 42. Please remember it.",
        "What is my favourite number multiplied by 2?",
    ]

    answers = []
    for turn in turns:
        result = graph.invoke(
            {"messages": [HumanMessage(content=turn)]},
            config=config,
        )
        last_ai = next(
            (m.content for m in reversed(result["messages"])
             if isinstance(m, AIMessage)),
            ""
        )
        answers.append(last_ai)

    return answers


# =============================================================
# SECTION B — Advanced RAG
# =============================================================

def _build_store(documents: list, collection: str) -> PGVector:
    """Helper: builds a PGVector store from a list of strings."""
    docs = [Document(page_content=d) for d in documents]
    return _pgvector_store(collection, docs=docs, pre_delete=True)


# ─────────────────────────────────────────────────────────────
# TASK 5 SOLUTION — Query Rewriting RAG
# ─────────────────────────────────────────────────────────────

def query_rewriting_rag(query: str, documents: list) -> dict:
    """Rewrites query then runs RAG. Returns original, rewritten, and answer."""

    llm    = _llm()
    parser = StrOutputParser()

    # Step 1: rewrite the query
    rewrite_prompt = ChatPromptTemplate.from_template(
        "Rewrite this query to be more specific and effective for searching "
        "a technical knowledge base about LangChain, RAG, and vector databases. "
        "Return ONLY the rewritten query, nothing else.\n\nOriginal: {query}"
    )
    rewritten = (rewrite_prompt | llm | parser).invoke({"query": query})

    # Step 2: retrieve using rewritten query
    store     = _build_store(documents, "query_rewrite_rag")
    retriever = store.as_retriever(search_kwargs={"k": 3})
    docs      = retriever.invoke(rewritten)
    context   = "\n\n".join(d.page_content for d in docs)

    # Step 3: answer
    answer_prompt = ChatPromptTemplate.from_template(
        "Answer using ONLY the context below. If unsure, say 'I don't know'.\n\n"
        "Context:\n{context}\n\nQuestion: {question}"
    )
    answer = (answer_prompt | llm | parser).invoke({
        "context": context,
        "question": rewritten,
    })

    return {"original": query, "rewritten": rewritten, "answer": answer}


# ─────────────────────────────────────────────────────────────
# TASK 6 SOLUTION — Multi-Query RAG
# ─────────────────────────────────────────────────────────────

def multi_query_rag(query: str, documents: list) -> dict:
    """Multi-query RAG with deduplication. Returns queries, doc count, answer."""

    llm    = _llm()
    parser = StrOutputParser()

    # Step 1: generate 3 query variants
    multi_prompt = ChatPromptTemplate.from_template(
        "Generate 3 different search queries to answer this question from "
        "multiple angles. Return them as a numbered list:\n"
        "1. ...\n2. ...\n3. ...\n\nQuestion: {question}"
    )
    raw_variants = (multi_prompt | llm | parser).invoke({"question": query})

    # Parse numbered list — extract lines starting with 1. 2. 3.
    generated_queries = []
    for line in raw_variants.strip().split("\n"):
        line = line.strip()
        match = re.match(r"^\d+\.\s+(.+)", line)
        if match:
            generated_queries.append(match.group(1).strip())

    # Fall back: split by newline if parsing failed
    if not generated_queries:
        generated_queries = [l.strip() for l in raw_variants.strip().split("\n") if l.strip()][:3]

    # Step 2: retrieve for each variant and deduplicate by content
    store     = _build_store(documents, "multi_query_rag")
    retriever = store.as_retriever(search_kwargs={"k": 2})

    seen_content = set()
    unique_docs  = []

    for q in generated_queries:
        for doc in retriever.invoke(q):
            if doc.page_content not in seen_content:
                seen_content.add(doc.page_content)
                unique_docs.append(doc)

    # Step 3: answer with merged context
    context = "\n\n".join(d.page_content for d in unique_docs)
    answer_prompt = ChatPromptTemplate.from_template(
        "Answer using ONLY the context below.\n\n"
        "Context:\n{context}\n\nQuestion: {question}"
    )
    answer = (answer_prompt | llm | parser).invoke({
        "context": context,
        "question": query,
    })

    return {
        "original_query"   : query,
        "generated_queries": generated_queries,
        "unique_doc_count" : len(unique_docs),
        "answer"           : answer,
    }


# ─────────────────────────────────────────────────────────────
# TASK 7 SOLUTION — Self-RAG with Document Grading
# ─────────────────────────────────────────────────────────────

def self_rag_with_grading(query: str, documents: list) -> dict:
    """Grades retrieved docs for relevance before answering."""

    llm    = _llm()
    parser = StrOutputParser()

    # Retrieve top-4 docs
    store     = _build_store(documents, "self_rag_grading")
    retriever = store.as_retriever(search_kwargs={"k": 4})
    retrieved = retriever.invoke(query)

    # Grade each doc
    grade_prompt = ChatPromptTemplate.from_template(
        "Is the following document relevant to answering the question below?\n\n"
        "Question: {query}\n\nDocument: {document}\n\n"
        "Answer YES or NO only."
    )
    grade_chain = grade_prompt | llm | parser

    relevant_docs = []
    for doc in retrieved:
        verdict = grade_chain.invoke({
            "query": query, "document": doc.page_content
        })
        if "yes" in verdict.lower():
            relevant_docs.append(doc)

    # Generate answer or fall back
    if not relevant_docs:
        answer = "I don't know."
    else:
        context = "\n\n".join(d.page_content for d in relevant_docs)
        answer_prompt = ChatPromptTemplate.from_template(
            "Answer using ONLY the context below. If unsure, say 'I don't know'.\n\n"
            "Context:\n{context}\n\nQuestion: {question}"
        )
        answer = (answer_prompt | llm | parser).invoke({
            "context": context, "question": query
        })

    return {
        "query"          : query,
        "retrieved_count": len(retrieved),
        "relevant_count" : len(relevant_docs),
        "answer"         : answer,
    }


# =============================================================
# SECTION C — Multimodal RAG
# =============================================================

# ─────────────────────────────────────────────────────────────
# TASK 8 SOLUTION — Image Description with GPT-4o Vision
# ─────────────────────────────────────────────────────────────

def describe_image(image_path: str) -> dict:
    """Describes an image using GPT-4o. Returns description and tags."""

    # Read and base64-encode the image
    with open(image_path, "rb") as f:
        b64_image = base64.b64encode(f.read()).decode("utf-8")

    # Determine MIME type from extension
    ext      = os.path.splitext(image_path)[1].lower().lstrip(".")
    mime_map = {"jpg": "image/jpeg", "jpeg": "image/jpeg",
                "png": "image/png",  "gif": "image/gif",
                "webp": "image/webp"}
    mime     = mime_map.get(ext, "image/png")

    # GPT-4o vision call
    vision_llm = ChatOpenAI(model="gpt-4o", max_tokens=300, temperature=0)

    description_msg = HumanMessage(content=[
        {"type": "text",      "text": "Describe this image in detail. What do you see?"},
        {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64_image}"}},
    ])
    description = vision_llm.invoke([description_msg]).content

    # Extract tags via a second LLM call
    tag_prompt = ChatPromptTemplate.from_template(
        "Extract 5-8 concise keyword tags from this image description. "
        "Return them as a comma-separated list only.\n\nDescription: {description}"
    )
    raw_tags  = (tag_prompt | _llm() | StrOutputParser()).invoke(
        {"description": description}
    )
    tags = [t.strip() for t in raw_tags.split(",") if t.strip()]

    return {
        "image_path" : image_path,
        "description": description,
        "tags"       : tags,
    }


# ─────────────────────────────────────────────────────────────
# TASK 9 SOLUTION — Multimodal Document Index
# ─────────────────────────────────────────────────────────────

def build_multimodal_index(text_docs: list, image_paths: list) -> dict:
    """Indexes text + image descriptions into a PGVector store."""

    all_docs = []

    # Index text documents
    for text in text_docs:
        all_docs.append(Document(
            page_content=text,
            metadata={"type": "text"},
        ))

    # Index image descriptions
    for path in image_paths:
        info = describe_image(path)
        all_docs.append(Document(
            page_content=info["description"],
            metadata={
                "type"      : "image",
                "image_path": path,
                "tags"      : info["tags"],
            },
        ))

    # Build the PGVector store
    _pgvector_store("multimodal_index", docs=all_docs, pre_delete=True)

    return {
        "text_docs_indexed" : len(text_docs),
        "image_docs_indexed": len(image_paths),
        "total_indexed"     : len(all_docs),
        "collection"        : "multimodal_index",
    }


# ─────────────────────────────────────────────────────────────
# TASK 10 SOLUTION — Multimodal RAG Query
# ─────────────────────────────────────────────────────────────

def multimodal_rag_query(query: str) -> dict:
    """Queries the multimodal index and returns answer with source types."""

    store  = _pgvector_store("multimodal_index")
    llm    = _llm()
    parser = StrOutputParser()

    # Retrieve top-3 docs with scores
    results = store.similarity_search_with_score(query, k=3)

    # Build context from retrieved docs
    context_parts = []
    sources       = []

    for doc, score in results:
        source_type = doc.metadata.get("type", "text")
        context_parts.append(
            f"[{source_type.upper()}] {doc.page_content}"
        )
        sources.append({
            "type"   : source_type,
            "content": doc.page_content,
            "score"  : float(score),
        })

    context = "\n\n".join(context_parts)

    # Generate answer
    answer_prompt = ChatPromptTemplate.from_template(
        "Answer using ONLY the context below. "
        "The context may contain TEXT and IMAGE descriptions.\n\n"
        "Context:\n{context}\n\nQuestion: {question}"
    )
    answer = (answer_prompt | llm | parser).invoke({
        "context": context, "question": query
    })

    return {"query": query, "answer": answer, "sources": sources}


# =============================================================
#  MAIN
# =============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("SOLUTION — LangGraph · Advanced RAG · Multimodal RAG")
    print("=" * 60)

    SAMPLE_IMAGE = create_sample_image("challenge_assets/sample.png")

    # ── Section A: LangGraph ─────────────────────────────────
    print("\n── SECTION A: LangGraph ───────────────────────────────\n")

    print("[Task 1] Basic StateGraph")
    r1 = basic_state_graph("LangGraph enables complex multi-step LLM workflows.")
    print("  Summary  :", r1["summary"][:100])
    print("  Critique :", r1["critique"][:100])

    print("\n[Task 2] Conditional Routing")
    r2 = conditional_routing_graph("Is Python a programming language?")
    print("  Raw answer    :", r2["raw_answer"][:60])
    print("  Final response:", r2["final_response"])

    print("\n[Task 3] ReAct Agent Loop")
    r3 = react_agent_graph("What is (7 * 6) + 15?")
    print("  Answer:", r3)

    print("\n[Task 4] Graph with Checkpointing")
    r4 = graph_with_checkpointing()
    print("  Turn 1:", r4[0][:100])
    print("  Turn 2:", r4[1][:100])

    # ── Section B: Advanced RAG ──────────────────────────────
    print("\n── SECTION B: Advanced RAG ────────────────────────────\n")

    print("[Task 5] Query Rewriting RAG")
    r5 = query_rewriting_rag("How does the graph thing work with memory?", RAG_DOCS)
    print("  Original :", r5["original"][:60])
    print("  Rewritten:", r5["rewritten"][:60])
    print("  Answer   :", r5["answer"][:120])

    print("\n[Task 6] Multi-Query RAG")
    r6 = multi_query_rag("What techniques improve RAG accuracy?", RAG_DOCS)
    print("  Generated queries:")
    for q in r6["generated_queries"]:
        print(f"    → {q[:70]}")
    print(f"  Unique docs: {r6['unique_doc_count']}")
    print(f"  Answer     : {r6['answer'][:120]}")

    print("\n[Task 7] Self-RAG with Grading")
    r7a = self_rag_with_grading(
        "What distance metrics does pgvector support?", RAG_DOCS
    )
    print("  [Relevant query]")
    print(f"  Retrieved: {r7a['retrieved_count']}  Relevant: {r7a['relevant_count']}")
    print(f"  Answer   : {r7a['answer'][:120]}")

    r7b = self_rag_with_grading("What is the capital of France?", RAG_DOCS)
    print("  [Irrelevant query]")
    print(f"  Retrieved: {r7b['retrieved_count']}  Relevant: {r7b['relevant_count']}")
    print(f"  Answer   : {r7b['answer']}")

    # ── Section C: Multimodal RAG ────────────────────────────
    print("\n── SECTION C: Multimodal RAG ──────────────────────────\n")

    print("[Task 8] Describe Image with GPT-4o")
    r8 = describe_image(SAMPLE_IMAGE)
    print("  Description:", r8["description"][:120])
    print("  Tags       :", r8["tags"])

    print("\n[Task 9] Build Multimodal Index")
    r9 = build_multimodal_index(RAG_DOCS, [SAMPLE_IMAGE])
    print(f"  Text docs  : {r9['text_docs_indexed']}")
    print(f"  Image docs : {r9['image_docs_indexed']}")
    print(f"  Total      : {r9['total_indexed']}")
    print(f"  Collection : {r9['collection']}")

    print("\n[Task 10] Multimodal RAG Query")
    r10 = multimodal_rag_query("What techniques extend RAG to images?")
    print("  Answer  :", r10["answer"][:150])
    print("  Sources :")
    for s in r10["sources"]:
        print(f"    [{s['type'].upper():5}  score={s['score']:.4f}]"
              f" {s['content'][:70]}")

    print("\n" + "=" * 60)
    print("All 10 tasks complete!")
    print("=" * 60)
