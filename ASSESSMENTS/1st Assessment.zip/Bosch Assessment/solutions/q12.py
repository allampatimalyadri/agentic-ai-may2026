def build_active_user_query(department):
    query = (
        "SELECT id, full_name FROM employees "
        "WHERE department = %s AND is_active = TRUE "
        "ORDER BY full_name ASC;"
    )
    return query, (department,)


sql, params = build_active_user_query("Sales")
print(sql)
print(params)
