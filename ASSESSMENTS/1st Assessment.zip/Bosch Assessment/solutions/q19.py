class InvalidScanError(Exception):
    pass


def normalize_scan(code):
    if "-" not in code:
        raise InvalidScanError(code)

    prefix, number = code.split("-", 1)

    if not number.isdigit():
        raise InvalidScanError(code)

    return f"{prefix.upper()}-{int(number):03d}"


def process_scans(scans):
    normalized = []
    failures = 0

    for scan in scans:
        try:
            normalized.append(normalize_scan(scan))
        except InvalidScanError:
            failures += 1

    return normalized, failures


print(process_scans(["kb-7", "ms-12", "bad", "tv-xx"]))
