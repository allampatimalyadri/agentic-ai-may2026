import json

try:
    from fastapi import FastAPI, HTTPException, status
    from pydantic import BaseModel
except ImportError:
    class BaseModel:
        def __init__(self, **data):
            for key, value in data.items():
                setattr(self, key, value)

        def dict(self):
            return self.__dict__

    class HTTPException(Exception):
        def __init__(self, status_code, detail):
            super().__init__(detail)
            self.status_code = status_code
            self.detail = detail

    class _Status:
        HTTP_404_NOT_FOUND = 404

    status = _Status()

    class FastAPI:
        def get(self, path, **kwargs):
            def decorator(func):
                return func

            return decorator


def to_dict(model):
    if hasattr(model, "model_dump"):
        return model.model_dump()
    if hasattr(model, "dict"):
        return model.dict()
    return model.__dict__


class InventoryResponse(BaseModel):
    sku: str
    stock: int


app = FastAPI()
inventory = {
    "KB-01": {"sku": "KB-01", "stock": 6},
}


@app.get("/inventory/{sku}")
def get_inventory_item(sku: str):
    item = inventory.get(sku)
    if item is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Item not found",
        )
    return InventoryResponse(**item)


print(json.dumps(to_dict(get_inventory_item("KB-01"))))

try:
    get_inventory_item("XX-99")
except HTTPException as exc:
    print(f"{exc.status_code} {exc.detail}")
