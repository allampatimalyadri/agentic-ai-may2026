results = {
    "Ava": [10, 15],
    "Liam": [12, 13],
    "Noah": [9, 10],
}


def build_leaderboard(results):
    totals = {name: sum(scores) for name, scores in results.items()}
    return sorted(totals.items(), key=lambda item: (-item[1], item[0]))


print(build_leaderboard(results))
