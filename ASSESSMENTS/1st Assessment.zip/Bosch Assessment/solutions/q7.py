import json

expenses = [
    {"category": "hardware", "amount": 1200},
    {"category": "software", "amount": 500},
    {"category": "hardware", "amount": 300},
    {"category": "software", "amount": 300},
]


def total_by_category(expenses):
    summary = {}
    for expense in expenses:
        category = expense["category"]
        summary[category] = summary.get(category, 0) + expense["amount"]
    return summary


print(json.dumps(total_by_category(expenses), sort_keys=True))
