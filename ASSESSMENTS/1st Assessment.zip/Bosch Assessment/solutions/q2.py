tasks = [
    {"title": "Design login page", "done": True},
    {"title": "Write API docs", "done": False},
    {"title": "Deploy staging build", "done": True},
]


def count_completed(tasks):
    completed = 0
    for task in tasks:
        if task["done"]:
            completed += 1
    return completed


print(count_completed(tasks))
