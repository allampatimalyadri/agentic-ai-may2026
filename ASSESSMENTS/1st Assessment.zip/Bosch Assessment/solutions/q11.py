import json

try:
    from fastapi import Depends, FastAPI, HTTPException, status
except ImportError:
    class HTTPException(Exception):
        def __init__(self, status_code, detail):
            super().__init__(detail)
            self.status_code = status_code
            self.detail = detail

    class _Status:
        HTTP_401_UNAUTHORIZED = 401

    status = _Status()

    def Depends(dependency):
        return dependency

    class FastAPI:
        def get(self, path, **kwargs):
            def decorator(func):
                return func

            return decorator


app = FastAPI()


def get_token():
    return "token-123"


@app.get("/reports")
def read_report(token: str = Depends(get_token)):
    if token != "token-123":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
        )
    return {"report": "weekly revenue"}


print(json.dumps(read_report(token=get_token())))
