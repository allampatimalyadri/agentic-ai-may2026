class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.balance = balance

    def deposit(self, amount):
        self.balance = self.balance + amount


account = BankAccount("Riya", 500)
account.deposit(250)
print(account.balance)
