def safe_divide(a, b):
    try:
        return round(a / b, 2)
    except ZeroDivisionError:
        return "Cannot divide by zero"


print(safe_divide(12, 0))
