tasks = [
    {"title": "Write tests", "priority": "high", "due_day": 3},
    {"title": "Fix bug", "priority": "high", "due_day": 1},
    {"title": "Refactor CSS", "priority": "low", "due_day": 2},
    {"title": "Prepare demo", "priority": "high", "due_day": 2},
]


def high_priority_titles(tasks):
    filtered = [task for task in tasks if task["priority"] == "high"]
    ordered = sorted(filtered, key=lambda task: (task["due_day"], task["title"]))
    return [task["title"] for task in ordered]


print(high_priority_titles(tasks))
