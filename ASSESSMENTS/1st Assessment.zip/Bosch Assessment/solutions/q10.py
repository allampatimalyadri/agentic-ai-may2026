ticket = {
    "issue": "Payment failed during checkout",
    "priority": "high",
}


def build_support_prompt(ticket):
    return (
        "You are a support assistant.\n"
        f"Customer issue: {ticket['issue']}\n"
        f"Priority: {ticket['priority']}\n"
        "Respond with: summary | next_step"
    )


print(build_support_prompt(ticket))
