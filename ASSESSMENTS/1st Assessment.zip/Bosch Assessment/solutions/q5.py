def apply_discount(prices):
    return [round(price * 0.9, 2) for price in prices]


print(apply_discount([100, 250, 80]))
