def keep_even(numbers):
    return [number for number in numbers if number % 2 == 0]


print(keep_even([3, 4, 7, 10, 13, 18]))
