posts = [
    {"title": "API Basics", "tags": ["python", "fastapi"]},
    {"title": "Prompt Design", "tags": ["genai", "python"]},
    {"title": "SQL Joins", "tags": ["postgres", "python"]},
]


def unique_tags(posts):
    return sorted({tag for post in posts for tag in post["tags"]})


print(unique_tags(posts))
