# Question 7: Total Expenses by Category
# Difficulty: Medium
# Topic: Python Data Aggregation
#
# Problem Statement:
# A finance script receives expense records with a category and amount.
# Complete the function so it returns the total amount spent in each category.
#
# Expected Output:
# {"hardware": 1500, "software": 800}

import json

expenses = [
    {"category": "hardware", "amount": 1200},
    {"category": "software", "amount": 500},
    {"category": "hardware", "amount": 300},
    {"category": "software", "amount": 300},
]


def total_by_category(expenses):
    summary = {}
    for expense in expenses:
        category = expense["category"]
        summary[category] = ___ + expense["amount"]
    return summary


print(json.dumps(total_by_category(expenses), sort_keys=True))
