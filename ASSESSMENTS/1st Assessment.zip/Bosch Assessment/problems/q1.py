# Question 1: Filter Even Sensor Readings
# Difficulty: Easy
# Topic: Python Basics
#
# Problem Statement:
# A monitoring script receives a list of sensor readings.
# Complete the function so it returns only the even readings.
#
# Expected Output:
# [4, 10, 18]

def keep_even(numbers):
    return [number for number in numbers if ___]


print(keep_even([3, 4, 7, 10, 13, 18]))
