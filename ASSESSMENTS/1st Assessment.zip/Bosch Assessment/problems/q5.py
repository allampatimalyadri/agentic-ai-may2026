# Question 5: Apply a Discount
# Difficulty: Easy
# Topic: Python Comprehensions
#
# Problem Statement:
# A store is applying a 10 percent discount to each product price.
# Complete the list comprehension so the discounted prices are returned.
#
# Expected Output:
# [90.0, 225.0, 72.0]

def apply_discount(prices):
    return [round(price * ___, 2) for price in prices]


print(apply_discount([100, 250, 80]))
