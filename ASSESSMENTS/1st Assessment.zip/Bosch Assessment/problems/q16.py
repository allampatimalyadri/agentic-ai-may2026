# Question 16: Summarize Open Orders
# Difficulty: Hard
# Topic: PostgreSQL JOIN and Python Integration
#
# Problem Statement:
# Complete the SQL query and the aggregation logic so the script summarizes
# the total open order amount for each customer after a JOIN.
#
# Expected Output:
# SELECT c.name, o.id, o.total FROM customers AS c JOIN orders AS o ON c.id = o.customer_id WHERE o.status = %s ORDER BY o.total DESC;
# [{"customer": "Maya", "total_open_amount": 325.0}, {"customer": "Arjun", "total_open_amount": 180.0}]

import json


def build_open_orders_query():
    return (
        "SELECT c.name, o.id, o.total FROM customers AS c "
        "JOIN orders AS o ON ___ "
        "WHERE o.status = %s "
        "ORDER BY o.total DESC;"
    )


def summarize_open_orders(rows):
    totals = {}
    for customer, order_id, total in rows:
        totals[customer] = totals.get(customer, 0) + ___
    ordered = sorted(totals.items(), key=lambda item: (-item[1], item[0]))
    return [
        {"customer": customer, "total_open_amount": amount}
        for customer, amount in ordered
    ]


rows = [
    ("Maya", 101, 250.0),
    ("Arjun", 102, 180.0),
    ("Maya", 103, 75.0),
]

print(build_open_orders_query())
print(json.dumps(summarize_open_orders(rows)))
