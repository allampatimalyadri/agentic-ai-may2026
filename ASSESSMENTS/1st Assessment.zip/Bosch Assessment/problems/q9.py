# Question 9: Create a Ticket Endpoint
# Difficulty: Medium
# Topic: FastAPI POST Endpoint
#
# Problem Statement:
# Complete the endpoint so a new ticket gets the next numeric id and
# the response model contains the created ticket data.
#
# Expected Output:
# {"id": 1, "title": "Fix login", "priority": "high"}

import json

try:
    from fastapi import FastAPI, status
    from pydantic import BaseModel
except ImportError:
    class BaseModel:
        def __init__(self, **data):
            for key, value in data.items():
                setattr(self, key, value)

        def dict(self):
            return self.__dict__

    class _Status:
        HTTP_201_CREATED = 201

    status = _Status()

    class FastAPI:
        def post(self, path, **kwargs):
            def decorator(func):
                return func

            return decorator


def to_dict(model):
    if hasattr(model, "model_dump"):
        return model.model_dump()
    if hasattr(model, "dict"):
        return model.dict()
    return model.__dict__


class TicketCreate(BaseModel):
    title: str
    priority: str


class TicketResponse(BaseModel):
    id: int
    title: str
    priority: str


app = FastAPI()
tickets = []


@app.post("/tickets", status_code=status.HTTP_201_CREATED)
def create_ticket(payload: TicketCreate):
    record = {
        "id": ___,
        "title": payload.title,
        "priority": payload.priority,
    }
    tickets.append(record)
    return TicketResponse(**record)


created = create_ticket(TicketCreate(title="Fix login", priority="high"))
print(json.dumps(to_dict(created)))
