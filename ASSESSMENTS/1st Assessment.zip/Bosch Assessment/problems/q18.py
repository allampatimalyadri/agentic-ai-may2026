# Question 18: Filter and Paginate Orders
# Difficulty: Hard
# Topic: FastAPI Filtering and Pagination
#
# Problem Statement:
# Complete the endpoint so it checks authorization, filters orders by
# minimum total, and returns only the requested number of results.
#
# Expected Output:
# [{"id": 2, "total": 150.0}, {"id": 3, "total": 220.0}]

import json

try:
    from fastapi import Depends, FastAPI, HTTPException, status
except ImportError:
    class HTTPException(Exception):
        def __init__(self, status_code, detail):
            super().__init__(detail)
            self.status_code = status_code
            self.detail = detail

    class _Status:
        HTTP_403_FORBIDDEN = 403

    status = _Status()

    def Depends(dependency):
        return dependency

    class FastAPI:
        def get(self, path, **kwargs):
            def decorator(func):
                return func

            return decorator


app = FastAPI()

orders = [
    {"id": 1, "total": 80.0},
    {"id": 2, "total": 150.0},
    {"id": 3, "total": 220.0},
    {"id": 4, "total": 120.0},
]


def get_is_admin():
    return True


@app.get("/orders")
def list_orders(
    min_total: float = 100.0,
    limit: int = 2,
    authorized: bool = Depends(get_is_admin),
):
    if not authorized:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Forbidden",
        )
    filtered = [order for order in orders if order["total"] >= min_total]
    return filtered[___]


print(json.dumps(list_orders(min_total=100.0, limit=2, authorized=get_is_admin())))
