# Question 19: Normalize Warehouse Scans
# Difficulty: Hard
# Topic: Python Exceptions and Data Normalization
#
# Problem Statement:
# A warehouse scanner sends product codes in mixed formats.
# Complete the normalization function so valid codes become uppercase with a
# three-digit numeric part, and invalid scans are counted as failures.
#
# Expected Output:
# (['KB-007', 'MS-012'], 2)

class InvalidScanError(Exception):
    pass


def normalize_scan(code):
    if "-" not in code:
        raise InvalidScanError(code)

    prefix, number = code.split("-", 1)

    if not number.isdigit():
        raise InvalidScanError(code)

    return f"{prefix.upper()}-{___}"


def process_scans(scans):
    normalized = []
    failures = 0

    for scan in scans:
        try:
            normalized.append(normalize_scan(scan))
        except InvalidScanError:
            failures += 1

    return normalized, failures


print(process_scans(["kb-7", "ms-12", "bad", "tv-xx"]))
