# Question 13: Build a Leaderboard
# Difficulty: Medium
# Topic: Python Functions and Sorting
#
# Problem Statement:
# A coding contest stores each participant's round scores in a dictionary.
# Complete the function so it returns a leaderboard sorted by total score
# descending and then by participant name ascending.
#
# Expected Output:
# [('Ava', 25), ('Liam', 25), ('Noah', 19)]

results = {
    "Ava": [10, 15],
    "Liam": [12, 13],
    "Noah": [9, 10],
}


def build_leaderboard(results):
    totals = {name: sum(scores) for name, scores in results.items()}
    return sorted(totals.items(), key=lambda item: ___)


print(build_leaderboard(results))
