"""
=============================================================
  SOLUTION FILE — LangChain · RAG · pgvector · LangSmith
  20-Task Coding Challenge
=============================================================
  Every function below is fully implemented.
  Run:  python langchain_rag_SOLUTION.py
=============================================================
"""

import os
import json
import numpy as np
from dotenv import load_dotenv

load_dotenv()

# ── LangChain core ────────────────────────────────────────────
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableParallel
from langchain_core.documents import Document
from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory

# ── LangChain OpenAI ──────────────────────────────────────────
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

# ── LangChain community / extras ──────────────────────────────
from langchain_community.vectorstores import PGVector
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.agents import create_react_agent, AgentExecutor
from langchain.tools import tool
from langchain.tools.retriever import create_retriever_tool
from langchain.chains import create_history_aware_retriever, create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain import hub

# ── pgvector (direct) ─────────────────────────────────────────
import psycopg2

# ── LangSmith ─────────────────────────────────────────────────
from langsmith import Client
from langsmith.evaluation import evaluate
from langchain_core.tracers.context import collect_runs

# ─────────────────────────────────────────────────────────────
# Shared helpers
# ─────────────────────────────────────────────────────────────

def _llm(temperature: float = 0) -> ChatOpenAI:
    return ChatOpenAI(model="gpt-4o-mini", temperature=temperature)

def _embeddings(model: str = "text-embedding-3-small") -> OpenAIEmbeddings:
    return OpenAIEmbeddings(model=model)

def _pg_conn():
    """Returns a psycopg2 connection using raw DSN env var."""
    return psycopg2.connect(os.environ["PG_CONNECTION_STRING_RAW"])


# =============================================================
# SECTION A — LangChain Core
# =============================================================

# ─────────────────────────────────────────────────────────────
# TASK 1 SOLUTION — Basic LCEL Chain
# ─────────────────────────────────────────────────────────────

def basic_lcel_chain(topic: str) -> str:
    """Returns a one-paragraph explanation of the given topic."""

    prompt = ChatPromptTemplate.from_template(
        "Explain {topic} in one concise paragraph suitable for a developer."
    )

    # Build the chain using the pipe operator (LCEL)
    chain = prompt | _llm() | StrOutputParser()

    return chain.invoke({"topic": topic})


# ─────────────────────────────────────────────────────────────
# TASK 2 SOLUTION — Sequential Chain
# ─────────────────────────────────────────────────────────────

def sequential_chain(topic: str) -> dict:
    """Returns {'summary': ..., 'translation': ...} for the topic."""

    llm    = _llm()
    parser = StrOutputParser()

    # Step 1 — summarise
    summary_prompt = ChatPromptTemplate.from_template(
        "Write exactly 3 sentences summarising: {topic}"
    )
    summary_chain = summary_prompt | llm | parser

    # Step 2 — translate
    translate_prompt = ChatPromptTemplate.from_template(
        "Translate the following text into French:\n\n{text}"
    )
    translate_chain = translate_prompt | llm | parser

    # Run sequentially
    summary     = summary_chain.invoke({"topic": topic})
    translation = translate_chain.invoke({"text": summary})

    return {"summary": summary, "translation": translation}


# ─────────────────────────────────────────────────────────────
# TASK 3 SOLUTION — Conversation Chain with Memory
# ─────────────────────────────────────────────────────────────

def conversation_with_memory() -> list:
    """Runs a 3-turn conversation and returns the full message history."""

    # Build the prompt with a placeholder for history
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful assistant. Answer concisely."),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{input}"),
    ])

    chain = prompt | _llm() | StrOutputParser()

    # In-memory store keyed by session_id
    store: dict = {}

    def get_session_history(session_id: str) -> InMemoryChatMessageHistory:
        if session_id not in store:
            store[session_id] = InMemoryChatMessageHistory()
        return store[session_id]

    chain_with_history = RunnableWithMessageHistory(
        chain,
        get_session_history,
        input_messages_key="input",
        history_messages_key="history",
    )

    session = {"configurable": {"session_id": "task3"}}
    turns = [
        "My name is Alex. What is machine learning?",
        "Can you give me a real-world example?",
        "What is my name?",
    ]

    for turn in turns:
        chain_with_history.invoke({"input": turn}, config=session)

    # Build a clean list of (role, content) tuples from the stored history
    history_obj = store["task3"]
    result = []
    for msg in history_obj.messages:
        role = "human" if isinstance(msg, HumanMessage) else "ai"
        result.append((role, msg.content))

    return result


# ─────────────────────────────────────────────────────────────
# TASK 4 SOLUTION — Agent with Custom Tools
# ─────────────────────────────────────────────────────────────

def agent_with_tools(query: str) -> str:
    """Runs a ReAct agent with custom tools and returns the final answer."""

    @tool
    def word_count(text: str) -> int:
        """Returns the number of words in the provided text."""
        return len(text.split())

    @tool
    def reverse_text(text: str) -> str:
        """Returns the input text with word order reversed."""
        return " ".join(text.split()[::-1])

    tools  = [word_count, reverse_text]
    prompt = hub.pull("hwchase17/react")
    agent  = create_react_agent(_llm(), tools, prompt)

    executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=False,
        handle_parsing_errors=True,
    )

    result = executor.invoke({"input": query})
    return result["output"]


# =============================================================
# SECTION B — Embeddings
# =============================================================

# ─────────────────────────────────────────────────────────────
# TASK 5 SOLUTION — Generate and Inspect Embeddings
# ─────────────────────────────────────────────────────────────

def generate_embeddings(sentences: list) -> dict:
    """Embeds a list of sentences and returns metadata + vectors."""

    emb     = _embeddings()
    vectors = emb.embed_documents(sentences)

    return {
        "num_sentences" : len(sentences),
        "embedding_dim" : len(vectors[0]),
        "first_5_values": vectors[0][:5],
        "vectors"       : vectors,
    }


# ─────────────────────────────────────────────────────────────
# TASK 6 SOLUTION — Cosine Similarity
# ─────────────────────────────────────────────────────────────

def cosine_similarity_manual(v1: list, v2: list) -> float:
    """Computes cosine similarity using pure Python."""

    dot_product = sum(a * b for a, b in zip(v1, v2))
    mag_v1      = sum(x ** 2 for x in v1) ** 0.5
    mag_v2      = sum(x ** 2 for x in v2) ** 0.5

    if mag_v1 == 0 or mag_v2 == 0:
        return 0.0

    return dot_product / (mag_v1 * mag_v2)


def cosine_similarity_numpy(v1: list, v2: list) -> float:
    """Computes cosine similarity using numpy."""

    a = np.array(v1)
    b = np.array(v2)

    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)

    if norm_a == 0 or norm_b == 0:
        return 0.0

    return float(np.dot(a, b) / (norm_a * norm_b))


def compare_word_pairs() -> dict:
    """Embeds dog/puppy and dog/automobile, compares similarities."""

    emb = _embeddings()
    dog        = emb.embed_query("dog")
    puppy      = emb.embed_query("puppy")
    automobile = emb.embed_query("automobile")

    sim_puppy      = cosine_similarity_numpy(dog, puppy)
    sim_automobile = cosine_similarity_numpy(dog, automobile)

    more_similar = "dog vs puppy" if sim_puppy > sim_automobile else "dog vs automobile"

    return {
        "dog_vs_puppy"      : sim_puppy,
        "dog_vs_automobile" : sim_automobile,
        "more_similar_pair" : more_similar,
    }


# ─────────────────────────────────────────────────────────────
# TASK 7 SOLUTION — Batch Embedding with Chunking
# ─────────────────────────────────────────────────────────────

SAMPLE_DOCUMENT = """
LangChain is a framework for developing applications powered by language models.
It provides tools for prompt management, chains, agents, and memory.
LangChain integrates with many LLM providers including OpenAI, Anthropic, and Cohere.
The framework also supports vector stores, document loaders, and output parsers.
RAG (Retrieval-Augmented Generation) is a technique that enhances LLM responses
by fetching relevant documents from a knowledge base at query time.
pgvector is a PostgreSQL extension that enables efficient storage and similarity
search of high-dimensional vector embeddings directly inside a relational database.
LangSmith is an observability platform for LangChain applications that provides
tracing, evaluation, and debugging of LLM pipelines.
"""

def batch_embed_with_chunks(text: str, chunk_size: int, overlap: int) -> dict:
    """Splits text into chunks, embeds them, and returns metadata."""

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=overlap,
    )
    chunks = splitter.split_text(text.strip())

    emb     = _embeddings()
    vectors = emb.embed_documents(chunks)

    return {
        "num_chunks"   : len(chunks),
        "chunk_size"   : chunk_size,
        "overlap"      : overlap,
        "embedding_dim": len(vectors[0]) if vectors else 0,
        "chunks"       : chunks,
    }


# ─────────────────────────────────────────────────────────────
# TASK 8 SOLUTION — Compare Two Embedding Models
# ─────────────────────────────────────────────────────────────

def compare_embedding_models(sentence: str) -> dict:
    """Embeds a sentence with two models and compares their dimensions."""

    model_a_name = "text-embedding-3-small"
    model_b_name = "text-embedding-3-large"

    emb_a   = OpenAIEmbeddings(model=model_a_name)
    emb_b   = OpenAIEmbeddings(model=model_b_name)

    vec_a   = emb_a.embed_query(sentence)
    vec_b   = emb_b.embed_query(sentence)

    dims_a  = len(vec_a)
    dims_b  = len(vec_b)

    return {
        "sentence": sentence,
        "model_a" : {"model": model_a_name, "dims": dims_a, "first_3": vec_a[:3]},
        "model_b" : {"model": model_b_name, "dims": dims_b, "first_3": vec_b[:3]},
        "dim_ratio": dims_b / dims_a,
    }


# =============================================================
# SECTION C — pgvector
# =============================================================

# ─────────────────────────────────────────────────────────────
# TASK 9 SOLUTION — Create pgvector Table
# ─────────────────────────────────────────────────────────────

def setup_pgvector_table() -> bool:
    """Creates the pgvector extension and documents table."""

    conn   = _pg_conn()
    cursor = conn.cursor()

    try:
        # Enable pgvector extension
        cursor.execute("CREATE EXTENSION IF NOT EXISTS vector")

        # Drop and recreate the table for a clean slate
        cursor.execute("DROP TABLE IF EXISTS documents")
        cursor.execute("""
            CREATE TABLE documents (
                id        SERIAL PRIMARY KEY,
                content   TEXT,
                metadata  JSONB,
                embedding vector(1536)
            )
        """)

        conn.commit()
        return True

    except Exception as e:
        conn.rollback()
        raise e

    finally:
        cursor.close()
        conn.close()


# ─────────────────────────────────────────────────────────────
# TASK 10 SOLUTION — Insert Documents
# ─────────────────────────────────────────────────────────────

def insert_documents(documents: list) -> int:
    """Embeds and inserts documents. Returns count of inserted rows."""

    emb    = _embeddings()
    conn   = _pg_conn()
    cursor = conn.cursor()

    count = 0
    try:
        for content, metadata in documents:
            vector = emb.embed_query(content)

            # psycopg2 needs the vector as a string: "[0.1, 0.2, ...]"
            cursor.execute(
                "INSERT INTO documents (content, metadata, embedding) VALUES (%s, %s, %s)",
                (content, json.dumps(metadata), str(vector))
            )
            count += 1

        conn.commit()

    except Exception as e:
        conn.rollback()
        raise e

    finally:
        cursor.close()
        conn.close()

    return count


# ─────────────────────────────────────────────────────────────
# TASK 11 SOLUTION — Similarity Search
# ─────────────────────────────────────────────────────────────

def similarity_search(query: str, top_k: int = 3) -> list:
    """Returns top-k similar documents for the query."""

    emb        = _embeddings()
    vector_str = str(emb.embed_query(query))

    conn   = _pg_conn()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT content, metadata, embedding <=> %s AS distance
            FROM documents
            ORDER BY distance ASC
            LIMIT %s
        """, (vector_str, top_k))

        rows = cursor.fetchall()

    finally:
        cursor.close()
        conn.close()

    return [
        {"content": row[0], "metadata": row[1], "distance": float(row[2])}
        for row in rows
    ]


# ─────────────────────────────────────────────────────────────
# TASK 12 SOLUTION — Metadata Filtering
# ─────────────────────────────────────────────────────────────

def filtered_search(query: str, source_filter: str, top_k: int = 3) -> list:
    """Returns top-k similar docs filtered by metadata source."""

    emb        = _embeddings()
    vector_str = str(emb.embed_query(query))

    conn   = _pg_conn()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT content, metadata, embedding <=> %s AS distance
            FROM documents
            WHERE metadata->>'source' = %s
            ORDER BY distance ASC
            LIMIT %s
        """, (vector_str, source_filter, top_k))

        rows = cursor.fetchall()

    finally:
        cursor.close()
        conn.close()

    return [
        {"content": row[0], "metadata": row[1], "distance": float(row[2])}
        for row in rows
    ]


# ─────────────────────────────────────────────────────────────
# TASK 13 SOLUTION — LangChain PGVector Integration
# ─────────────────────────────────────────────────────────────

def langchain_pgvector_search(documents: list, query: str, top_k: int = 3) -> list:
    """Creates a PGVector store and runs a scored similarity search."""

    emb  = _embeddings()
    docs = [Document(page_content=c, metadata=m) for c, m in documents]

    store = PGVector.from_documents(
        documents=docs,
        embedding=emb,
        collection_name="lc_documents",
        connection_string=os.environ["PG_CONNECTION_STRING"],
        pre_delete_collection=True,   # fresh start each run
    )

    # Returns list of (Document, score) tuples
    results = store.similarity_search_with_score(query, k=top_k)
    return results


# =============================================================
# SECTION D — RAG Agents
# =============================================================

def _build_pgvector_store(documents: list, collection: str = "rag_store") -> PGVector:
    """Helper: creates a PGVector store from a list of string documents."""
    emb  = _embeddings()
    docs = [Document(page_content=d) for d in documents]
    return PGVector.from_documents(
        documents=docs,
        embedding=emb,
        collection_name=collection,
        connection_string=os.environ["PG_CONNECTION_STRING"],
        pre_delete_collection=True,
    )


# ─────────────────────────────────────────────────────────────
# TASK 14 SOLUTION — Basic RAG Pipeline
# ─────────────────────────────────────────────────────────────

RAG_DOCUMENTS = [
    "LangChain v0.2 introduced LangChain Expression Language (LCEL) for composing chains.",
    "pgvector is a PostgreSQL extension supporting L2, inner product, and cosine distance.",
    "LangSmith provides tracing for every LLM call including token counts and latency.",
    "RAG stands for Retrieval-Augmented Generation and improves factual accuracy of LLMs.",
    "OpenAI's text-embedding-3-small produces 1536-dimensional embedding vectors.",
    "LangChain agents use a ReAct loop: Thought → Action → Observation → Answer.",
]

def basic_rag_pipeline(documents: list, question: str) -> str:
    """Indexes documents and answers the question using RAG."""

    store     = _build_pgvector_store(documents, "basic_rag")
    retriever = store.as_retriever(search_kwargs={"k": 3})

    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    prompt = ChatPromptTemplate.from_template(
        "Answer the question using ONLY the context below. "
        "If unsure, say 'I don't know'.\n\n"
        "Context:\n{context}\n\n"
        "Question: {question}"
    )

    # LCEL chain
    chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | _llm()
        | StrOutputParser()
    )

    return chain.invoke(question)


# ─────────────────────────────────────────────────────────────
# TASK 15 SOLUTION — RAG with Source Attribution
# ─────────────────────────────────────────────────────────────

def rag_with_sources(documents: list, question: str) -> dict:
    """Returns the answer AND the source documents used."""

    store     = _build_pgvector_store(documents, "rag_sources")
    retriever = store.as_retriever(search_kwargs={"k": 3})

    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    prompt = ChatPromptTemplate.from_template(
        "Answer using ONLY the context below.\n\n"
        "Context:\n{context}\n\n"
        "Question: {question}"
    )

    # Retrieve docs first so we can use them as both context and sources
    retrieved_docs = retriever.invoke(question)
    context_text   = format_docs(retrieved_docs)

    answer_chain   = prompt | _llm() | StrOutputParser()
    answer         = answer_chain.invoke({"context": context_text, "question": question})

    # Build sources list with similarity scores
    scored_docs = store.similarity_search_with_score(question, k=3)
    sources = [
        {"content": doc.page_content, "score": float(score)}
        for doc, score in scored_docs
    ]

    return {"answer": answer, "sources": sources}


# ─────────────────────────────────────────────────────────────
# TASK 16 SOLUTION — Conversational RAG
# ─────────────────────────────────────────────────────────────

def conversational_rag(documents: list) -> list:
    """Returns [answer_turn1, answer_turn2] for a 2-turn RAG conversation."""

    store     = _build_pgvector_store(documents, "conv_rag")
    retriever = store.as_retriever(search_kwargs={"k": 3})
    llm       = _llm()

    # Prompt to rephrase a follow-up into a standalone question
    contextualize_prompt = ChatPromptTemplate.from_messages([
        ("system",
         "Given the chat history and a follow-up question, rephrase the "
         "follow-up as a standalone question. Return ONLY the question."),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])

    # History-aware retriever — rewrites the query before retrieval
    history_aware_retriever = create_history_aware_retriever(
        llm, retriever, contextualize_prompt
    )

    # QA prompt
    qa_prompt = ChatPromptTemplate.from_messages([
        ("system",
         "Answer the question using ONLY the context below. "
         "If unsure, say 'I don't know'.\n\n{context}"),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])

    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
    rag_chain             = create_retrieval_chain(history_aware_retriever, question_answer_chain)

    chat_history = []
    answers      = []

    turns = [
        "What is LangChain?",
        "What version introduced LCEL?",
    ]

    for turn in turns:
        response = rag_chain.invoke({"input": turn, "chat_history": chat_history})
        answer   = response["answer"]
        answers.append(answer)

        # Append human + AI messages to history for the next turn
        chat_history.append(HumanMessage(content=turn))
        chat_history.append(AIMessage(content=answer))

    return answers


# ─────────────────────────────────────────────────────────────
# TASK 17 SOLUTION — RAG Agent (Tool-based Retrieval)
# ─────────────────────────────────────────────────────────────

def rag_agent(question: str) -> str:
    """Uses a ReAct agent with a retriever tool to answer the question."""

    store     = _build_pgvector_store(RAG_DOCUMENTS, "rag_agent_store")
    retriever = store.as_retriever(search_kwargs={"k": 3})

    retriever_tool = create_retriever_tool(
        retriever,
        name="knowledge_base",
        description=(
            "Search the technical knowledge base about LangChain, pgvector, "
            "RAG, embeddings, and LangSmith. Use this for any technical questions."
        ),
    )

    tools  = [retriever_tool]
    prompt = hub.pull("hwchase17/react")
    agent  = create_react_agent(_llm(), tools, prompt)

    executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=False,
        handle_parsing_errors=True,
    )

    result = executor.invoke({"input": question})
    return result["output"]


# =============================================================
# SECTION E — LangSmith
# =============================================================

# ─────────────────────────────────────────────────────────────
# TASK 18 SOLUTION — Traced Chain
# ─────────────────────────────────────────────────────────────

def traced_chain(topic: str) -> dict:
    """Runs a chain with LangSmith tracing. Returns answer and run_id."""

    # Ensure tracing env vars are set
    os.environ.setdefault("LANGCHAIN_TRACING_V2", "true")
    os.environ.setdefault("LANGCHAIN_PROJECT",    "rag-challenge")

    prompt = ChatPromptTemplate.from_template(
        "Explain {topic} in one concise paragraph for a developer."
    )
    chain = prompt | _llm() | StrOutputParser()

    with collect_runs() as cb:
        result = chain.invoke(
            {"topic": topic},
            config={
                "run_name": "task18_trace",
                "tags":     ["challenge", "task18"],
            },
        )

    run_id = str(cb.traced_runs[0].id) if cb.traced_runs else "unknown"
    return {"answer": result, "run_id": run_id}


# ─────────────────────────────────────────────────────────────
# TASK 19 SOLUTION — Create LangSmith Dataset
# ─────────────────────────────────────────────────────────────

def create_langsmith_dataset() -> str:
    """Creates a LangSmith dataset with 3 examples. Returns dataset id."""

    client = Client()

    dataset_name = "rag-eval-dataset"

    # Delete existing dataset with the same name to avoid duplicates
    try:
        existing = client.read_dataset(dataset_name=dataset_name)
        client.delete_dataset(dataset_id=existing.id)
    except Exception:
        pass  # dataset didn't exist yet

    dataset = client.create_dataset(
        dataset_name=dataset_name,
        description="Evaluation dataset for the RAG coding challenge",
    )

    questions = [
        "What does RAG stand for?",
        "What PostgreSQL extension enables vector search?",
        "What LangChain tool provides observability?",
    ]
    answers = [
        "Retrieval-Augmented Generation",
        "pgvector",
        "LangSmith",
    ]

    client.create_examples(
        inputs=[{"question": q} for q in questions],
        outputs=[{"answer": a} for a in answers],
        dataset_id=dataset.id,
    )

    return str(dataset.id)


# ─────────────────────────────────────────────────────────────
# TASK 20 SOLUTION — Run LangSmith Evaluation
# ─────────────────────────────────────────────────────────────

def run_langsmith_evaluation() -> dict:
    """Evaluates the RAG pipeline on the LangSmith dataset."""

    # Ensure dataset exists
    dataset_id = create_langsmith_dataset()

    # Target function: receives {"question": str}, returns {"answer": str}
    def target(inputs: dict) -> dict:
        answer = basic_rag_pipeline(RAG_DOCUMENTS, inputs["question"])
        return {"answer": answer}

    # Custom evaluator: checks if expected answer appears in generated answer
    def contains_answer(run, example) -> dict:
        generated = run.outputs.get("answer", "").lower()
        expected  = example.outputs.get("answer", "").lower()
        passed    = expected in generated
        return {"key": "contains_answer", "score": int(passed)}

    results = evaluate(
        target,
        data="rag-eval-dataset",
        evaluators=[contains_answer],
        experiment_prefix="rag-challenge-eval",
    )

    # Compute pass rate from results
    scores    = [r["evaluation_results"]["results"][0].score for r in results]
    pass_rate = sum(scores) / len(scores) if scores else 0.0

    return {
        "dataset"     : "rag-eval-dataset",
        "num_examples": len(scores),
        "pass_rate"   : pass_rate,
    }


# =============================================================
#  MAIN — runs all 20 solutions
# =============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("SOLUTION — LangChain · RAG · pgvector · LangSmith")
    print("=" * 60)

    # ── Section A ─────────────────────────────────────────────
    print("\n── SECTION A: LangChain Core ──────────────────────────\n")

    print("[Task 1] Basic LCEL Chain")
    r1 = basic_lcel_chain("vector databases")
    print(" ", r1[:120])

    print("\n[Task 2] Sequential Chain")
    r2 = sequential_chain("transformer architecture")
    print("  Summary    :", r2["summary"][:80])
    print("  Translation:", r2["translation"][:80])

    print("\n[Task 3] Conversation with Memory")
    r3 = conversation_with_memory()
    for role, msg in r3:
        print(f"  [{role.upper():5}] {msg[:80]}")

    print("\n[Task 4] Agent with Custom Tools")
    r4 = agent_with_tools("How many words are in 'The quick brown fox'? Also reverse it.")
    print(" ", r4)

    # ── Section B ─────────────────────────────────────────────
    print("\n── SECTION B: Embeddings ──────────────────────────────\n")

    sentences = [
        "LangChain simplifies LLM application development.",
        "pgvector adds vector search to PostgreSQL.",
        "RAG grounds language models with external knowledge.",
    ]

    print("[Task 5] Generate Embeddings")
    r5 = generate_embeddings(sentences)
    print(f"  Sentences : {r5['num_sentences']}")
    print(f"  Dimensions: {r5['embedding_dim']}")
    print(f"  First 5   : {[round(v,4) for v in r5['first_5_values']]}")

    print("\n[Task 6] Cosine Similarity")
    r6 = compare_word_pairs()
    print(f"  dog vs puppy      : {r6['dog_vs_puppy']:.4f}")
    print(f"  dog vs automobile : {r6['dog_vs_automobile']:.4f}")
    print(f"  More similar      : {r6['more_similar_pair']}")

    print("\n[Task 7] Batch Embedding with Chunking")
    r7 = batch_embed_with_chunks(SAMPLE_DOCUMENT, 200, 40)
    print(f"  Chunks     : {r7['num_chunks']}")
    print(f"  Embed dims : {r7['embedding_dim']}")
    for i, chunk in enumerate(r7["chunks"]):
        print(f"  Chunk {i+1}   : {chunk[:60]}...")

    print("\n[Task 8] Compare Embedding Models")
    r8 = compare_embedding_models("Vector databases power semantic search.")
    print(f"  Model A ({r8['model_a']['model']}) dims : {r8['model_a']['dims']}")
    print(f"  Model B ({r8['model_b']['model']}) dims : {r8['model_b']['dims']}")
    print(f"  Dim ratio  : {r8['dim_ratio']:.1f}x")

    # ── Section C ─────────────────────────────────────────────
    print("\n── SECTION C: pgvector ────────────────────────────────\n")

    docs_to_insert = [
        ("LangChain enables LLM pipelines.", {"source": "docs", "page": 1}),
        ("pgvector stores vector embeddings.", {"source": "docs", "page": 2}),
        ("RAG retrieves relevant context.",   {"source": "paper", "page": 5}),
        ("LangSmith traces LLM calls.",       {"source": "blog",  "page": 1}),
    ]

    print("[Task 9] Setup pgvector Table")
    print(f"  Table created: {setup_pgvector_table()}")

    print("\n[Task 10] Insert Documents")
    print(f"  Rows inserted: {insert_documents(docs_to_insert)}")

    print("\n[Task 11] Similarity Search")
    for r in similarity_search("How does LangSmith help?", top_k=2):
        print(f"  [{r['distance']:.4f}] {r['content']}")

    print("\n[Task 12] Filtered Search (source=blog)")
    for r in filtered_search("LLM tracing", source_filter="blog", top_k=2):
        print(f"  [{r['distance']:.4f}] {r['content']}")

    print("\n[Task 13] LangChain PGVector Integration")
    for doc, score in langchain_pgvector_search(docs_to_insert, "vector embeddings", top_k=2):
        print(f"  [score={score:.4f}] {doc.page_content}")

    # ── Section D ─────────────────────────────────────────────
    print("\n── SECTION D: RAG Agents ──────────────────────────────\n")

    print("[Task 14] Basic RAG Pipeline")
    print(" ", basic_rag_pipeline(RAG_DOCUMENTS, "What is LCEL?")[:120])

    print("\n[Task 15] RAG with Sources")
    r15 = rag_with_sources(RAG_DOCUMENTS, "What distance metrics does pgvector support?")
    print("  Answer  :", r15["answer"][:100])
    for s in r15["sources"]:
        print(f"  [{s['score']:.4f}] {s['content'][:60]}")

    print("\n[Task 16] Conversational RAG")
    r16 = conversational_rag(RAG_DOCUMENTS)
    print("  Turn 1:", r16[0][:100])
    print("  Turn 2:", r16[1][:100])

    print("\n[Task 17] RAG Agent")
    print(" ", rag_agent("What distance metrics does pgvector support?")[:120])

    # ── Section E ─────────────────────────────────────────────
    print("\n── SECTION E: LangSmith ───────────────────────────────\n")

    print("[Task 18] Traced Chain")
    r18 = traced_chain("embeddings")
    print(f"  Answer : {str(r18['answer'])[:80]}")
    print(f"  Run ID : {r18['run_id']}")

    print("\n[Task 19] Create LangSmith Dataset")
    print(f"  Dataset ID: {create_langsmith_dataset()}")

    print("\n[Task 20] Run LangSmith Evaluation")
    r20 = run_langsmith_evaluation()
    print(f"  Dataset     : {r20['dataset']}")
    print(f"  # Examples  : {r20['num_examples']}")
    print(f"  Pass rate   : {r20['pass_rate']:.0%}")

    print("\n" + "=" * 60)
    print("All 20 solutions complete!")
    print("=" * 60)
